#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
    Actor(int ID, int x, int y, int direction, int depth, double size, bool dead, bool takesDamage, StudentWorld* world);
    bool willTakeDamage() const;
    bool isDead() const;
    virtual bool isSolid() =0;
    StudentWorld* getWorld() const;
    virtual void doSomething()=0;

    virtual void bonk();
    void setDead(){
        m_dead= true;
    }

private:
    
    bool m_dead;
    bool m_takesDamage;
    StudentWorld* m_world;
    
};
class Block : public Actor{
public:
    Block(int x, int y, StudentWorld* world);
    virtual void doSomething();

    virtual bool isSolid(){
        return true;
    }
    virtual void bonk();
private:

};

class Peach : public Actor{
public:
    Peach(int x, int y, StudentWorld* world);
    virtual void doSomething();
    virtual bool isSolid(){
        return false;
    }
    void canShoot(){
        m_shoot=true;
    }
    void cantShoot(){
        m_shoot=false;
    }
    void gotMushroom(){
        m_jumpPower= true;
    }
    void lostMushroom(){
        m_jumpPower=false;
    }
    
    void gotStar(){
        m_invincible= true;
    }
    void lostStar(){
        m_invincible=false;;
    }
    int getInvTickCount() const;
    bool isInvincible() const{
        return m_invincible;
    }
    virtual void bonk();
    void decHp(){
        m_hp--;
    }
    void hpUp(){
        m_hp = 2;
    }
    void losePower();
private:
    int m_hp;
    int time_to_recharge_before_next_fire;
    int m_InvTickCount;
    bool m_shoot;
    bool m_invincible;
    bool m_jumpPower;
    int remaining_jump_power;
 //   void bonk();
};
class Pipe : public Actor{
public:
    Pipe(int x, int y, StudentWorld* world);
    virtual void doSomething();
    virtual bool isSolid(){
        return true;
    }
    virtual void bonk();
    
};
class InteractableObject : public Actor{
public:
    InteractableObject(bool holdsGoodie, int ID, int x, int y, int direction, int depth, double size, bool dead, bool takesDamage, StudentWorld* world) :
    Actor(ID,  x, y,direction, depth,  size, dead, takesDamage,  world){};

    virtual bool isSolid(){
        return false;
    }

    bool hasGoodie(){
        return goody;
    }
    void useGoodie(){
        goody = false;
    }
    void initGoodie(){
        goody = true;
    }
private:
    bool goody;
};

class Flag : public InteractableObject {
public:
    Flag(bool holdsGoodie, int x, int y, StudentWorld* world);
    virtual bool isSolid(){
        return false;
    }
    virtual void bonk();
    virtual void doSomething();

    
};

class FlowerBlock : public InteractableObject{
public:
    FlowerBlock(bool holdsGoodie, int x, int y, StudentWorld* world);

    virtual bool isSolid(){
        return true;
    }

    virtual void doSomething();
    virtual void bonk();
    

};
class MushroomBlock : public InteractableObject{
public:
    MushroomBlock(bool holdsGoodie, int x, int y, StudentWorld* world);

    virtual bool isSolid(){
        return true;
    }

    virtual void doSomething();
    virtual void bonk();
   

};
class StarBlock : public InteractableObject{
public:
    StarBlock(bool holdsGoodie, int x, int y, StudentWorld* world);

    virtual bool isSolid(){
        return true;
    }

    virtual void doSomething();
    virtual void bonk();
   

};
class PowerUp : public Actor{
public:
    PowerUp(int ID, int x, int y, int direction, int depth, double size, bool dead, bool takesDamage, StudentWorld* world) :
    Actor(ID,  x, y,direction, depth,  size, dead, takesDamage,  world){};

    virtual bool isSolid(){
        return false;
    }
    virtual int getScoreIncrease()=0;
    void doSomething();
private:
    virtual void powerUp()=0;
    

};
class Flower : public PowerUp{
public:
    Flower(int x, int y, StudentWorld* world);
    virtual int getScoreIncrease(){
        return 50;
    }

private:
    virtual void powerUp();
    

};
class Mushroom : public PowerUp{
public:
    Mushroom(int x, int y, StudentWorld* world);
    virtual int getScoreIncrease(){
        return 75;
    }

private:
    virtual void powerUp();
    

};
class Star : public PowerUp{
public:
    Star(int x, int y, StudentWorld* world);
    virtual int getScoreIncrease(){
        return 100;
    }

private:
    virtual void powerUp();
    

};
class MovingEnemy : public Actor{
public:
    MovingEnemy(int ID, int x, int y, int direction, int depth, double size, bool dead, bool takesDamage, StudentWorld* world) :
    Actor(ID,  x, y,direction, depth,  size, dead, takesDamage,  world){};

    virtual bool isSolid(){
        return false;
    }
    virtual int getScoreIncrease()=0;
    void doSomething();
    
private:
   
};
class Goomba : public MovingEnemy{
public:
    Goomba(int x, int y, StudentWorld* world);
    virtual int getScoreIncrease(){
        return 100;
    }
};
class Koopa : public MovingEnemy{
public:
    Koopa(int x, int y, StudentWorld* world);
    virtual int getScoreIncrease(){
        return 100;
    }
};
class Pirahna : public Actor{
public:
    Pirahna(int x, int y, StudentWorld* world);
    
};
#endif // ACTOR_H_


