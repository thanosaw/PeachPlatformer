#include "Actor.h"
#include "StudentWorld.h"
#include "GameWorld.h"
#include <iostream>
using namespace std;
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
// Actor implementation
Actor::Actor(int ID, int startX, int startY, int direction, int depth, double size, bool alive, bool takesDamage, StudentWorld* world) : GraphObject(ID, startX, startY, direction, size, depth)
{

    m_dead = false;
    m_world = world;
    m_takesDamage = takesDamage;
}
void Actor::bonk(){
    
}
//void Actor::doSomething(){
//
//}
bool Actor::willTakeDamage()const{
    return m_takesDamage;
}
bool Actor::isDead() const {
    return m_dead;
}
StudentWorld* Actor::getWorld() const{
    return m_world;
}
Block::Block(int x, int y, StudentWorld* world) :
Actor(IID_BLOCK, x, y, 0, 1, 2, false, false, world){
}
void Block::doSomething(){
    if (isDead()){
        return;
    }
    
}
void Block::bonk(){
    getWorld()->playSound(SOUND_PLAYER_BONK);
    cout<< "bonked block" << endl;
}

Peach::Peach(int x, int y, StudentWorld* world) :
Actor(IID_PEACH, x, y, 0, 0, 1.0, false, true, world){
    m_invincible = false;
    remaining_jump_power=0;
    m_shoot=false;
    time_to_recharge_before_next_fire =0;
    m_hp=1;
    m_star=false;
    m_InvTickCount=0;
    m_jumpPower=false;
}
void Peach::bonk(){
    
}
void Peach::setInvTickCount(int ticks){
    m_invincible=true;
    m_InvTickCount = ticks;
}
int Peach::getInvTickCount() const{
    return m_InvTickCount;
}

void Peach::losePower(){
    m_invincible=false;
    m_jumpPower=false;
    m_hp=1;
    m_shoot=false;
}

void Peach::doSomething(){
    //Check if dead
    //jump height implemented
    //invincibility not implemented
    //implement hp
    if (getHp()<=0){
        getWorld()->playSound(SOUND_PLAYER_DIE);
        setDead();
    }
    if (isDead())
        return;
//    cout << getY() << endl;
    if (m_invincible&&m_InvTickCount>0){
        
        m_InvTickCount--;
    }
    else{
        m_invincible=false;
    }
    
    time_to_recharge_before_next_fire--;
    int input;
    if (remaining_jump_power>0){
        if (getWorld()->canMove(getX(), getY()+4, false)){
            moveTo(getX(), getY()+4);
        }
        else{
            remaining_jump_power=0;
        }
        remaining_jump_power = remaining_jump_power-1;
    }
    else{
        
        if (getWorld()->canMove(getX(), getY()-3, true)){
            moveTo(getX(), getY()-4);

        }
    }
    if (getWorld()->getKey(input)){
        switch(input){
            case KEY_PRESS_LEFT:
                setDirection(180);
                if (getX()-4>=0&&getWorld()->canMove(getX()-4,getY(), false)){
                    moveTo(getX()-4,getY());
                    
                    break;
                }
                else
                break;
                
            case KEY_PRESS_RIGHT:
                setDirection(0);
                if (getX()+4<VIEW_WIDTH&&getWorld()->canMove(getX()+4,getY(), false)){
                    moveTo(getX()+4,getY());
                    
                    break;
                }
                else
                break;
            case KEY_PRESS_UP:
                if (!getWorld()->canMove(getX(),getY()-2, true)){
                    int jHeight = 8;
                    if (m_jumpPower){
                        jHeight=32;
                    }
                    remaining_jump_power = jHeight;
                }
                break;
            case KEY_PRESS_SPACE:
                if (!m_shoot||time_to_recharge_before_next_fire >0){
                    
                    break;
                }
                else{
                    time_to_recharge_before_next_fire =8;
                    getWorld()->playSound(SOUND_PLAYER_FIRE);
                    break;
                }
                
                
        }
        
        
    }
    
    
}
Pipe::Pipe(int x, int y, StudentWorld* world) :
Actor(IID_PIPE, x, y, 0, 1, 2, false, false, world){
}

void Pipe::doSomething(){
    if (isDead()){
        return;
    }
    
}
void Pipe::bonk(){
    cout<< "bonked pipe" << endl;
}
Flag::Flag(bool holdsGoodie, int x, int y, StudentWorld* world) :
InteractableObject(false, IID_FLAG, x, y, 0, 1, 1, false, false, world){
}
void Flag::bonk(){
    
    
        return;
    
}

void Flag::doSomething(){
    if (isDead()){
        return;
    }
    if(getWorld()->overlap(this)&&!isDead()){
        cout << "on flag" << endl;
        getWorld()->increaseScore(1000);
        setDead();
        getWorld()->playSound(SOUND_FINISHED_LEVEL);
        getWorld()->finishLevel();
    }
    
}

FlowerBlock::FlowerBlock(bool holdsGoodie, int x, int y, StudentWorld* world) :
InteractableObject(true, IID_BLOCK, x, y, 0, 1, 2, false, false, world){
    initGoodie();
}


void FlowerBlock::doSomething(){
    
}
void FlowerBlock::bonk(){
    if (hasGoodie()){
        getWorld()->addFlower(getX(),getY()+8);
        getWorld()->playSound(SOUND_POWERUP_APPEARS);
        cout << "release Flower" << endl;
        useGoodie();
    }
    else{
        getWorld()->playSound(SOUND_PLAYER_BONK);
    }
}
MushroomBlock::MushroomBlock(bool holdsGoodie, int x, int y, StudentWorld* world) :
InteractableObject(true, IID_BLOCK, x, y, 0, 1, 2, false, false, world){
    initGoodie();
}


void MushroomBlock::doSomething(){
    
}
void MushroomBlock::bonk(){
    if (hasGoodie()){
        getWorld()->addMushroom(getX(), getY()+8);
        getWorld()->playSound(SOUND_POWERUP_APPEARS);
        cout << "release Mushroom" << endl;
        useGoodie();
    }
    else{
        getWorld()->playSound(SOUND_PLAYER_BONK);
    }
}
StarBlock::StarBlock(bool holdsGoodie, int x, int y, StudentWorld* world) :
InteractableObject(true, IID_BLOCK, x, y, 0, 1, 2, false, false, world){
    initGoodie();
}


void StarBlock::doSomething(){
    
}
void StarBlock::bonk(){
    if (hasGoodie()){
        getWorld()->addStar(getX(),getY()+8);
        getWorld()->playSound(SOUND_POWERUP_APPEARS);
        cout << "release Star" << endl;
        useGoodie();
    }
    else{
        getWorld()->playSound(SOUND_PLAYER_BONK);
    }
}
void PowerUp::doSomething(){
    if (isDead()){
        return;
    }
    if(getWorld()->overlap(this)&&!isDead()){
        getWorld()->increaseScore(getScoreIncrease());
        getWorld()->playSound(SOUND_PLAYER_POWERUP);
        setDead();
        powerUp();
    }
    if (getWorld()->canMove(getX(),getY()-2,true)){
        moveTo(getX(),getY()-2);
    }
    if (getDirection()==0&&getWorld()->canMove(getX()+2,getY(),true)){
        moveTo(getX()+2,getY());
    }
    else if (getDirection()==180&&getWorld()->canMove(getX()-2,getY(),true)){
        moveTo(getX()-2,getY());
    }
    else{
        if (getDirection()==0){
            setDirection(180);
        }
        else{
            setDirection(0);
        }
    }
}
Flower::Flower(int x, int y, StudentWorld* world):
PowerUp(IID_FLOWER, x, y, 0, 1, 1, false, false, world){
    
}

void Flower::powerUp(){
    cout << "Got Flower!!" << endl;
    getWorld()->flowerPower();
    return;
}
Mushroom::Mushroom(int x, int y, StudentWorld* world):
PowerUp(IID_MUSHROOM, x, y, 0, 1, 1, false, false, world){
    
}

void Mushroom::powerUp(){
    cout << "Got mushroom!!" << endl;
    getWorld()->mushroomPower();
    return;
}

Star::Star(int x, int y, StudentWorld* world):
PowerUp(IID_STAR, x, y, 0, 1, 1, false, false, world){
    
}

void Star::powerUp(){
    cout << "Got star!!" << endl;
    getWorld()->starPower();
    return;
}

void MovingEnemy::doSomething(){
    
    
    if (isDead()){

        return;
    }
    if(getWorld()->overlap(this)&&!isDead()){
        cout << "OMG U DIED!!!" << endl;
        if (getWorld()->hasStar()){
            setDead();
            return;
        }
        getWorld()->takeDamage();
        return;
    }
    
    if (getDirection()==0&&getWorld()->canMove(getX()+SPRITE_WIDTH,getY()-2,true)){
        setDirection(180);
    }
    else if (getDirection()==180&&getWorld()->canMove(getX()-SPRITE_WIDTH,getY()-2,true)){
        setDirection(0);
    }
    if (getDirection()==0&&getWorld()->canMove(getX()+1,getY(),true)){
        moveTo(getX()+1,getY());
    }
    else if (getDirection()==180&&getWorld()->canMove(getX()-1,getY(),true)){
        moveTo(getX()-1,getY());
    }
    else{
        if (getDirection()==0){
            setDirection(180);
        }
        else{
            setDirection(0);
        }
    }
}
Goomba::Goomba(int x, int y, StudentWorld* world):
MovingEnemy(IID_GOOMBA, x, y, 0, 1, 1, false, false, world){
    int randDir = rand() %3 +1;
    cout << randDir << "dir" << endl;
     if (randDir==1){
        setDirection(0);
    }
    else{
        setDirection(180);
    }
}
Koopa::Koopa(int x, int y, StudentWorld* world):
MovingEnemy(IID_KOOPA, x, y, 0, 1, 1, false, false, world){
    int randDir = rand() %3 +1;
    cout << randDir << "dir" << endl;
     if (randDir==1){
        setDirection(0);
    }
    else{
        setDirection(180);
    }
}
Pirahna::Pirahna(int x, int y, StudentWorld* world) :
Actor(IID_PIRANHA, x, y, 0, 0, 1.0, false, true, world){
    int randDir = rand() %3 +1;
    cout << randDir << "dir" << endl;
     if (randDir==1){
        setDirection(0);
    }
    else{
        setDirection(180);
    }
    m_firingDelay =0;
}
void Pirahna::doSomething(){
    if (isDead()){

        return;
    }
    if(getWorld()->overlap(this)&&!isDead()){
        cout << "OMG U DIED!!!" << endl;
        getWorld()->takeDamage();
        
        return;
    }
    
}
void Pirahna::bonk(){
    
}
void Fireball::doSomething(){
    if (isDead()){

        return;
    }
    if(getWorld()->overlap(this)&&!isDead()){
        cout << "OMG U DIED!!!" << endl;
        getWorld()->takeDamage();
        setDead();
        return;
    }
    
    if (getWorld()->canMove(getX(), getY()-2, true)){
        moveTo(getX(), getY()-2);

    }
    if (getDirection()==0&&getWorld()->canMove(getX()+2,getY(),true)){
        moveTo(getX()+2,getY());
    }
    else if (getDirection()==180&&getWorld()->canMove(getX()-2,getY(),true)){
        moveTo(getX()-2,getY());
    }
    else{
        setDead();
    }
}
